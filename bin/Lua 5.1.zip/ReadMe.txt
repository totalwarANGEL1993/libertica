Installation:

- Copy "Lua 5.1" to the programs directory
  (e.g. "C:/Program Files/Lua 5.1")
- Add lua to PATH variable
  (e.g. "C:/Program Files/Lua 5.1/bin")
- Restart your PC

Uninstall:

- Remove lua from PATH variable
- Delete "Lua 5.1" from programms directory
- Restart your PC