-- authors: Luxinia Dev (Eike Decker & Christoph Kubisch)
---------------------------------------------------------

return {
  exts = {"txt"},
  --lexer = wxstc.wxSTC_LEX_POV,
  --apitype = "luxres",
  linecomment = ">",
}
